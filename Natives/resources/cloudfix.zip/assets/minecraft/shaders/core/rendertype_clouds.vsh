#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

layout(std140) uniform CloudInfo {
    vec4 CloudColor;
    vec3 CloudOffset;
    vec3 CellSize;
};

out float vertexDistance;
out vec4 vertexColor;

// ANGLE-on-Metal cannot compile texelFetch on isamplerBuffer (CloudFaces),
// so this override emits degenerate geometry instead: every vertex lands on
// the same point, nothing is rasterized, but the pipeline compiles and links.
// Clouds are invisible; everything else renders normally.
void main() {
    gl_Position = vec4(0.0, 0.0, 0.0, 1.0);
    vertexDistance = 0.0;
    vertexColor = vec4(0.0) * CloudColor;
}
